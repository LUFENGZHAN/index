//仿百度
let ipt = document.querySelector("#ipt"),
    aul = document.querySelector("#list");

ipt.oninput = () => {
    let val = ipt.value;
    let url = "https://www.baidu.com/sugrec?prod=pc&from=pc_web&wd=" + val + "&cb=zhan";
    let scr = document.createElement("script");
    scr.src = url;
    document.body.appendChild(scr);
};

function zhan(data) {
    let html = "";
    // console.log(date);
    data.g && data.g.forEach((itm) => {

        html += `<li>${itm.q}</li>`;
    })
    list.innerHTML = html;
}
window.zhan = zhan;
//轮播图
let rot = document.getElementById('rot-chart');
let aimg = document.querySelector(".rot-img");
let aimmg = document.querySelectorAll(".rot-img img");
let aleft = document.querySelector(".left");
let aright = document.querySelector(".right");
let abtn = document.querySelectorAll(".rot-btns > span");
let len = abtn.length;
let index = 0;
let time;
console.log(aimg, aimmg, aleft, aright, abtn);
//操作页面
function changhtml(i) {
    aimg.style.marginLeft = -(i + 1) + "00%";
    aimg.style.transition = " .4s";
    if (i === len || i === -1) {
        let left = i === len ? "-100%" : "-200%";
        setTimeout(
            function() {
                aimg.style.transition = " 0s";
                aimg.style.marginLeft = left
            }, 320)
    };
    //去除class样式
    abtn[index].classList.remove("rot-on");

    index = i;

    index %= len; // 不能超过len 当前值除4得余数
    if (index < 0) {
        index = len - 1;
    }
    // 当前显示添加
    abtn[index].classList.add("rot-on");
};
//下侧按钮
abtn.forEach((ele, i) => {
    ele.onclick = function() {
        changhtml(i);
    };
});
aright.onclick = function() {
    changhtml(index + 1);
};
aleft.onclick = function() {
    changhtml(index - 1);
};

//计时器
rot.onmouseenter = function() {
    clearInterval(time);
};

rot.onmouseleave = (function x() {
    time = setInterval(function() {
        changhtml(index + 1);

    }, 1000);
    return x;
})();